//Calculate Tip
function calculateTip() {
    let getAmount = document.getElementById("billamt");
    // if there is no input in the bill, gives an alert
    if (getAmount.value === "") {
        alert("Please enter values");
    }
    else {
        let getNumberOfPeople = document.getElementById("peopleamt");
        // if the number of people is 0 or negative or nothing input, default the value as 1
        if (parseInt(getNumberOfPeople.value) <= 0 || getNumberOfPeople.value === "") {
            getNumberOfPeople.value = "1";
        }

        let tipPercentage = document.getElementById("serviceQual");
        // calculate the tip amount for each person
        let tipAmount = parseInt(getAmount.value) * tipPercentage.value / parseInt(getNumberOfPeople.value);
        // calculate the total amount for each person
        let totalAmount = parseInt(getAmount.value) / parseInt(getNumberOfPeople.value) + tipAmount;
        // display the results in the div
        let display = document.getElementById("totalAndTip");
        display.innerHTML = `TIP AMOUNT<br/>$${tipAmount}<br/>each<br/>TOTAL AMOUNT<br/>$${totalAmount}<br/>each`;
        // make an XHR request, call the function below
        sendData();
    }
}
// this function is make an XHR request, and gives an alert
function sendData() {
    const xhrObj = new XMLHttpRequest();
    xhrObj.open("GET", "https://swapi.co/api/people/20");
    xhrObj.onload = function (e) {
        let myJson = xhrObj.response;
        let myObjectFromJson = JSON.parse(xhrObj.response);
        alert(`You have won a ${myObjectFromJson.name} toy`);
        // prints an error in the console      
        console.error("error detected");
    };
    xhrObj.send();
}