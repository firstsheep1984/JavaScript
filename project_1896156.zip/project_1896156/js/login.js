//  when click the button "Login", it will check whether the email and password is effective.
//  if passed, weather will show up; if not, reminding messages will show up
function add() {
    let getPassword = document.getElementById("secondInput");
    const string = "Error! Please complete the form!"
    if (!ValidateEmail(document.form1.text1)) {
        const message = "*Email address must be filled in!";
        addElement(string);
        addElement(message);
    }

    if (getPassword.value.length < 6) {
        const message = "*Password length must be at least 6 characters!";
        addElement(message);
    }

    if (ValidateEmail(document.form1.text1) && getPassword.value.length >= 6) {
        addNewLi2();
        let spanContent = document.getElementsByTagName("span");
        spanContent[0].innerHTML = "You have logged in successfully.";
        let displayAll = document.getElementById('displayAll');
        displayAll.innerHTML = "";
    }
}

// reference: https://www.w3resource.com/javascript/form/email-validation.php
// this function is to judge whether the user's input format matches the standard email format
function ValidateEmail(inputText) {
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

    if (inputText.value.match(mailformat)) {
        document.form1.text1.focus();
        return true;
    }
    else {       
        document.form1.text1.focus();
        return false;
    }
}
// when login unsuccessfully, message will show here
function addElement(message) {
    let newTag = document.createElement('p');
    newTag.innerHTML = message;
    let displayAll = document.getElementById('displayAll');
    displayAll.appendChild(newTag);
}

// if login successfully, the user will get the next 5 days' weather information
function addNewLi2() {
    const xhrObj = new XMLHttpRequest();
    xhrObj.open("GET", "http://dataservice.accuweather.com/forecasts/v1/daily/5day/56186?apikey=72FQaXW0kMS11l5xxeuT7DFQdfmA8keu&metric=true");
    xhrObj.onload = function (e) {
        let myJson = xhrObj.response;
        let myObjectFromJson = JSON.parse(xhrObj.response);
        let weatherKeyword = myObjectFromJson["DailyForecasts"];

        console.log(myObjectFromJson);
        console.log(weatherKeyword);

        weatherKeyword.forEach(element => {
            let message = "";
            message = `${message} <a href="http://www.accuweather.com/en/ca/montreal/h3a/daily-weather-forecast/56186?day=1&unit=c&lang=en-us" target="_blank">${element["Date"]}</a><br/>Max: ${element["Temperature"]["Maximum"]["Value"]}C Min: ${element["Temperature"]["Maximum"]["Value"]}C <br/>Day: ${element["Day"]["IconPhrase"]} Night: ${element["Night"]["IconPhrase"]}`;

            let liTag = document.createElement("li");
            liTag.innerHTML = message;
            let weatherList = document.getElementById("weather-list");
            weatherList.appendChild(liTag);

        });
    };
    xhrObj.send();
}